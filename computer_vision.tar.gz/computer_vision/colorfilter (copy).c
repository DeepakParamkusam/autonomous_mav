/*
 * Copyright (C) 2015
 *
 * This file is part of Paparazzi.
 *
 * Paparazzi is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * Paparazzi is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Paparazzi; see the file COPYING.  If not, write to
 * the Free Software Foundation, 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

/**
 * @file modules/computer_vision/colorfilter.c
 */

// Own header
#include "modules/computer_vision/colorfilter.h"
#include <stdio.h>
#include <opencv_bebop/opencv/modules/core/include/opencv2/core/core.hpp>
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/core/core.hpp"
#include "modules/computer_vision/lib/vision/image.h"
#include "opencv_image_functions.h"
#include "modules/computer_vision/cv.h"

using namespace cv;
using namespace std;

struct video_listener *listener = NULL;
struct video_listener *listener2 = NULL;
struct video_listener *listener3 = NULL;

// Filter Settings
uint8_t color_lum_min = 20;
uint8_t color_lum_max = 255;
uint8_t color_cb_min  = 75;
uint8_t color_cb_max  = 145;
uint8_t color_cr_min  = 167;
uint8_t color_cr_max  = 255;

uint8_t color_lum_min_g = 20;
uint8_t color_lum_max_g = 255;
uint8_t color_cb_min_g  = 0;
uint8_t color_cb_max_g  = 128;
uint8_t color_cr_min_g  = 0;
uint8_t color_cr_max_g  = 128;

// Result
int color_count = 0;
int color_count_l = 0;
int color_count_r = 0;
int color_count_g = 0;
int Sign = 0;
int H_bott = 0;

// Function
struct image_t *colorfilter_bottom(struct image_t *img);
struct image_t *colorfilter_bottom(struct image_t *img)
{
  // Filter
  color_count_g = image_yuv422_colorfilt(img, img,
                                       color_lum_min_g, color_lum_max_g,
                                       color_cb_min_g, color_cb_max_g,
                                       color_cr_min_g, color_cr_max_g
                                      );

  return img; // Colorfilter did not make a new image
}

struct image_t *colorfilter_func(struct image_t *img);
struct image_t *colorfilter_func(struct image_t *img)
{
  // Filter
  color_count = image_yuv422_colorfilt(img, img,
                                       color_lum_min, color_lum_max,
                                       color_cb_min, color_cb_max,
                                       color_cr_min, color_cr_max
                                      );
  color_count_l = image_yuv422_colorfilt_l(img, img,
                                       color_lum_min, color_lum_max,
                                       color_cb_min, color_cb_max,
                                       color_cr_min, color_cr_max
                                      );
  color_count_r = image_yuv422_colorfilt_r(img, img,
                                       color_lum_min, color_lum_max,
                                       color_cb_min, color_cb_max,
                                       color_cr_min, color_cr_max
                                      );

  return img; // Colorfilter did not make a new image
}


struct image_t *grassDetection(struct image_t *image);
struct image_t *grassDetection(struct image_t *image)
{
  Mat M(image->h, image->w, CV_8UC2, image);
  Mat img;
  Mat planes[3];   //destination array
  cvtColor(M, img, CV_YUV2BGR_Y422);
  split(img,planes);
  int W = img.cols;
  int H = img.rows;
  //Note: OpenCV uses BGR color order
  int isgrass[H][W];
  int i=0,j=0;
  for(int i = 0; i<H; i++){
    for(int j = 0; j<W; j++){
      Scalar pr = planes[0].at<uchar>(i,j);
      Scalar pg = planes[1].at<uchar>(i,j);
      Scalar pb = planes[2].at<uchar>(i,j);
      if((pg.val[0] > pr.val[0]+8)&&(pg.val[0] > pb.val[0]+8)&&(pg.val[0] > 60)){
        isgrass[i][j] = 1;
      }
      else{
        isgrass[i][j] = 0;
      }
    }
  }
  int m,n,CoW;
  int S = 1;
  int WSum = 0;
  for(i = H-1; i > H/2; i-= 4)
  {
    S = 1; 
    WSum = 0;
    for(m = W/4-1; m < (W*3/4-1); m++){
      S += 1 - isgrass[i][m];
      WSum += m*(1 - isgrass[i][m]);
    }
    CoW = WSum/S+1;
    Sign = 0;
    H_bott = i;
    if( (S > W/40) && (CoW - W/2) < W/5){
      if(i > 9*H/10){
        WSum = 0;
        S = 1;
        for(m = W/4-1; m < (W*3/4-1); m++){
          for(n = i - H/5; n < i; n++){
            WSum += m*(1 - isgrass[n][m]);
            S += 1 - isgrass[n][m];
          }

          WSum = WSum/S;

          Sign = -1;

          if(WSum < W/2){
            Sign = 1;
          }
        }
      }
      break;
    }
  }
/*/    Mat bgr[3];   //destination array
    Mat I_b,I_g,I_r;

    split(img, bgr);

    int W,H;

    W = img.cols;
    H = img.rows;
    //Note: OpenCV uses BGR color order
    I_b = bgr[0];
    I_g = bgr[1];
    I_r = bgr[2];

    int isgrass[H][W];
    int i,j;

    for (i = 0; i < H; i++){
      for(j = 0; j< W; j++){
        if(I_g[i][j] > (I_r[i][j] + 10) && (I_g[j][j] > (I_b[i][j] + 10)) && (I_g[i][j] > 72)){
          isgrass[i][j] = 1;
        }

        else{
          isgrass[i][j] = 0;
        }

      }
    }
    int m,n, CoW, H_bott;
    int S = 0;
    int WSum = 0;

    for(i = H; i > H/2; i-= 4){
      for(m = W/4; m < W*3/4; m++){
        S += 1 - isgrass[i][m];
        WSum += m*(1 - isgrass[i][m]);
      }
      CoW = WSum/S/255;
      if( (S > W/40) && (CoW - W/2) < W/5){
        H_bott = i;
        Sign = 0;
        if(i > 9*H/10){
          WSum = 0;
          S = 0;
          for(m = W/4; m < W*3/4; m++){
            for(n = i - W/5 + 1; n < i; n++){
              WSum += m*(1 - isgrass[n][m]);
              S += 1 - isgrass[n][m];
            }
            WSum = WSum/S;
            Sign = -1;

            if(WSum < W/2){
              Sign = 1;
            }
          }
        }
        break
      }
    }
/*/
    return image;
}

void colorfilter_init(void)
{
//  listener = cv_add_to_device(&COLORFILTER_CAMERA, colorfilter_func);
//  listener2 = cv_add_to_device(&COLORFILTER_BOTTOM, colorfilter_bottom);
  listener3 = cv_add_to_device(&COLORFILTER_CAMERA, grassDetection);
}
