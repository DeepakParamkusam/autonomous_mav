If you have your own autonomous aircraft, it is really apriciated if you would:
* Create your own short UPPERCASE directory name within this one, e.g. "MYX"
* Prefix your airframe names with the same name in lowercase and add an underscore, e.g. myx_superdart.xml

This will make your life of updating Paparazzi much simpler...

It can be helpful to take a look at how other paparazzi enthousiasts like you did just that.

TIP: Remember to put the following DOCTYPE line in the top of your airframe file: 

 <!DOCTYPE airframe SYSTEM "../airframe.dtd">

Have a great day!
