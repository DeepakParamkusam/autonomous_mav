// CHDKPTP Pipe

void chdk_pipe_init(void);
void chdk_pipe_shoot(char *filename);
void chdk_pipe_deinit(void);

