# CATIA

**C**amera **A**application **T**triggering **I**mage **A**nalysis

Application to capture camera images, store GPS and attitude information, trigger the processing of the image and return the results.

Sources in `sw/airborne/modules/digital_cam/catia`.
