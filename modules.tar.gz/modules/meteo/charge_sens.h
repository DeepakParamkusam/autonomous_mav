#ifndef CHARGE_SENS_H
#define CHARGE_SENS_H

#include "std.h"

void charge_sens_init(void);
void charge_sens_periodic(void);
void charge_sens_event(void);

#endif

