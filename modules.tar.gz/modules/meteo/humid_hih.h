#ifndef HUMID_HIH_H
#define HUMID_HIH_H

#include <std.h>

extern uint16_t adc_humid_hih;
void humid_hih_init(void);
void humid_hih_periodic(void);

#endif
