#ifndef GEIGER_COUNTER_H
#define GEIGER_COUNTER_H

#include "std.h"

void geiger_counter_init(void);
void geiger_counter_periodic(void);
void geiger_counter_event(void);

#endif

