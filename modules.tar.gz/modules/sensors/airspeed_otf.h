#ifndef AIRSPEED_OTF_H
#define AIRSPEED_OTF_H

#include "std.h"

void airspeed_otf_parse(char c);
void airspeed_otf_init(void);
void airspeed_otf_event(void);
void airspeed_otf_periodic(void);

#endif
