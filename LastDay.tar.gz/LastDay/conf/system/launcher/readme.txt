Ubuntu shortcut

To create a shortcut on the desktop to easily start Paparazzi copy the launcher to the desktop

cp Paparazzi.desktop ~/Desktop

and edit it to fit your username. Replace USERNAME with your actual user name in the 'Icon' and 'Exec' lines.

gedit ~/Desktop/Paparazzi.desktop
